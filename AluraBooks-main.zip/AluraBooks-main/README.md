# AluraBooks
Projeto feito durante o curso mobile-first da Alura

Um projeto responsivo que foi desenvolvido com suporte a diversas plataformas (mobile, tablet e desktop) com diferentes tamanhos de tela. Comecei pela plataforma mobile pois utilizei a metodologia mobile-first, um ótimo método de desenvolvimento para se começar o projeto pois ao final da versão mobile a pessoa desenvolvedora já tem grande parte do projeto concluído, só restando alguns ajustes a serem feitos usando @media queries. Além de fazer uso dessa metodologia também tive acesso a alguns conceitos inicias de JavaScript, e também a importação de arquivos ja prontos para serem usados 

Gostaria de agradecer a plataforma da Alura e também a instrutora Mônica Hillman, pois agregaram muito a minha jornada de aprendizado através desse curso 
